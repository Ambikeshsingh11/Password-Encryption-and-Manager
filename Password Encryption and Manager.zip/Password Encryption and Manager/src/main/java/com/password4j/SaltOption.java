package com.password4j;

public enum SaltOption
{
    PREPEND, APPEND;
}
